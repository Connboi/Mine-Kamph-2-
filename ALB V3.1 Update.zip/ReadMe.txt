Note: This is my first lucky block add-on. I did this without any training on how to make a lucky block
and only learned how by digging into the LuckyBlockProperties.txt file. Anyways, here is how t0 install this add-on.

How To Install

1: Launch Minecraft with the lucky block mod installed.

2: Drop the config folder into the .minecraft folder.

3: Open the Lucky Block Mod's .jar file and follow this file path assets/lucky/textures/blocks.

4: Drop the .png file into the blocks folder.

5: Play, because you have installed The Apocalypse Lucky Block Add-on.

Story: Long ago, it was a usual normal boring day in the world of minecraft, except for a town mystic who predicted that the world would end
and how the 4 Horsemen of the apocalypse would break out of the nether to attack the humans.
Not many people believed the mystic but enough people believed her for the story to be spread. But little to the knowledge of sceptics, a day
later, The 4 Horsemen came bursting out of the nether and captured a town.
                                             After capturing the town, The 4 Horsemen gave a proposition to the humans, where various humans
would undergo "The Apocalypse Lucky Block Challenge" in exchange to be spared from The Horemen's Wrath. The challengers would break numerous
Apocalypse Lucky Blocks until they're deemed worthy. However, the Apocalypse Lucky Block (Doomus Fortunus Blockus) was just as deadly as 
The Horsemen.This knowledge split the humans into 2 groups. Those who chose to be mercy killed by the horsemen. And those who try to open as 
many lucky blocks as possible, trying to save themselves. 
                                             However, there were a group of people in between who wanted to fight for humanity's freedoom, they
were The Rebels. The Rebels sought to free humanity from its shackles and defeat The 4 Horsemen once and for all, and encouraged people to join
them. However, with the high amount of danger, being a rebel wasn't easy. But as more and more deaths piled on from the block, more and more
people joined The Rebels. To the point where they have become a significant threat to The Horsemen. You're kind of in the middle of the war
between the 2 factions, because you're believed to be a member of the horsemen's army, even though you're still atemptting the challenge. So,
yeah, both The Horsemen and Rebels hate you basically.

QnA

Q: How do install this?
A: Read above.

Q: I'm having (insert issue here). What do i do?
A: I'm no tech head, its best you have someone else inspect the mod and let us know what's causing the issue and how to fix it.

Q: I'm having issues controlling the unlucky mobs!
A: Not my problem.

Q: Where's the 1.8 version.
A: Its coming whenever i learn how to make a 1.8 version.

Q: (Insert Troll Comment Here)
A: I only accept questions.